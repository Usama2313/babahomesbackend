export const countryCityMap = {
  UAE: ["Dubai", "Abu Dhabi", "Sharjah", "Ajman"],
  "Saudi Arabia": ["Riyadh", "Jeddah", "Dammam", "Makkah"],
  Bahrain: ["Manama", "Muharraq", "Riffa", "Isa Town"],
  Qatar: ["Doha", "Al Wakrah", "Lusail", "Al Rayyan"],
  India: ["Mumbai", "Delhi", "Bangalore", "Hyderabad"],
  Pakistan: ["Lahore", "Karachi", "Islamabad", "Rawalpindi"]
};

export const countries = Object.keys(countryCityMap);

export const fallbackProperties = [
  {
    _id: "1",
    title: "Luxury Apartment in Dubai Marina",
    country: "UAE",
    city: "Dubai",
    price: 1250000,
    currency: "AED",
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c",
    type: "Apartment",
    category: "Buy",
    bedrooms: 2,
    bathrooms: 2,
    area: "1,250 sqft",
    address: "Dubai Marina, UAE"
  },
  {
    _id: "2",
    title: "Modern Villa in Manama",
    country: "Bahrain",
    city: "Manama",
    price: 350000,
    currency: "BHD",
    image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750",
    type: "Villa",
    category: "Buy",
    bedrooms: 4,
    bathrooms: 3,
    area: "3,500 sqft",
    address: "Amwaj Islands, Manama"
  }
];
