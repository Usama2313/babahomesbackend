import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { User, Mail, Phone, MapPin, Camera, Save, ArrowLeft } from "lucide-react";
import toast from "react-hot-toast";
import API from "../api";
import { countryCityMap } from "../utils/constants";
import Navbar from "../components/Navbar";

const ProfilePage = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    country: "",
    city: "",
    profilePicture: ""
  });

  const countries = Object.keys(countryCityMap);
  const cities = form.country ? countryCityMap[form.country] : [];

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await API.get("/auth/me");
        setForm({
          name: res.data.name || "",
          email: res.data.email || "",
          phone: res.data.phone || "",
          country: res.data.country || "",
          city: res.data.city || "",
          profilePicture: res.data.profilePicture || ""
        });

        // Update local storage user data to keep navbar in sync
        const storedUser = JSON.parse(localStorage.getItem("babaUser") || "{}");
        localStorage.setItem("babaUser", JSON.stringify({ ...storedUser, ...res.data }));
      } catch (error) {
        toast.error("Failed to load profile.");
        if (error.response?.status === 401) {
          navigate("/login");
        }
      } finally {
        setFetching(false);
      }
    };
    fetchProfile();
  }, [navigate]);

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error("Image size must be less than 5MB");
        return;
      }
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        setForm({ ...form, profilePicture: reader.result });
      };
      reader.onerror = () => {
        toast.error("Failed to read image file.");
      };
    }
  };

  const handleSave = async () => {
    try {
      setLoading(true);
      const res = await API.put("/auth/profile", form);
      toast.success(res.data.message || "Profile updated successfully!");

      // Update local storage
      const storedUser = JSON.parse(localStorage.getItem("babaUser") || "{}");
      localStorage.setItem("babaUser", JSON.stringify({ ...storedUser, ...form, profilePicture: form.profilePicture }));

      // Trigger a storage event manually so Navbar updates
      window.dispatchEvent(new Event("storage"));
    } catch (error) {
      toast.error(error.response?.data?.message || "Error updating profile.");
    } finally {
      setLoading(false);
    }
  };

  if (fetching) {
    return (
      <div className="pageMessage">
        <div className="loaderSpinner"></div>
        <p>Loading Profile...</p>
      </div>
    );
  }

  return (
    <>
      <Navbar />
      <div className="profileLayout">
        <motion.div
          className="profileContainer"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="profileHeader">
            <button className="backBtnIcon" onClick={() => navigate("/")}>
              <ArrowLeft size={20} />
            </button>
            <h2>My Profile</h2>
          </div>

          <div className="profileContent">
            <div className="profileSidebar">
              <div className="avatarWrapper">
                {form.profilePicture ? (
                  <img src={form.profilePicture} alt="Profile" className="profileAvatarImg" />
                ) : (
                  <div className="profileAvatarFallback">
                    {form.name ? form.name.charAt(0).toUpperCase() : <User size={40} />}
                  </div>
                )}
                <label className="uploadOverlay">
                  <Camera size={20} />
                  <input type="file" accept="image/*" onChange={handleImageUpload} hidden />
                </label>
              </div>
              <h3>{form.name || "User"}</h3>
              <p>{form.email}</p>
            </div>

            <div className="profileForm">
              <h3>Personal Information</h3>

              <div className="formGrid">
                <div className="formGroup">
                  <label><User size={16} /> Full Name</label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={e => setForm({ ...form, name: e.target.value })}
                    placeholder="Enter your name"
                  />
                </div>
                <div className="formGroup">
                  <label><Mail size={16} /> Email Address</label>
                  <input
                    type="email"
                    value={form.email}
                    readOnly
                    className="readOnlyInput"
                  />
                </div>
                <div className="formGroup">
                  <label><Phone size={16} /> Phone Number</label>
                  <input
                    type="tel"
                    value={form.phone}
                    onChange={e => setForm({ ...form, phone: e.target.value })}
                    placeholder="Enter phone number"
                  />
                </div>
              </div>

              <h3 className="sectionTitle">Location</h3>
              <div className="formGrid">
                <div className="formGroup">
                  <label><MapPin size={16} /> Country</label>
                  <select
                    value={form.country}
                    onChange={e => setForm({ ...form, country: e.target.value, city: "" })}
                  >
                    <option value="">Select Country</option>
                    {countries.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="formGroup">
                  <label><MapPin size={16} /> City</label>
                  <select
                    value={form.city}
                    onChange={e => setForm({ ...form, city: e.target.value })}
                    disabled={!form.country}
                  >
                    <option value="">Select City</option>
                    {cities.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>

              <div className="formActions">
                <button
                  className="continueBtn"
                  onClick={handleSave}
                  disabled={loading}
                >
                  {loading ? "Saving..." : <><Save size={18} /> Save Changes</>}
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default ProfilePage;
