// routes/authRoutes.js
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { Op } = require("sequelize");
const User = require("../models/User.js");

const router = express.Router();

router.post("/register", async (req, res) => {
    try {
        const { name, email, phone, password } = req.body;

        const exists = await User.findOne({
            where: {
                [Op.or]: [{ email }, { phone }],
            },
        });

        if (exists) {
            return res.status(400).json({
                message: "User already exists with this email or phone",
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const user = await User.create({
            name,
            email,
            phone,
            password: hashedPassword,
        });

        const userData = user.toJSON();
        delete userData.password;

        res.status(201).json({
            message: "Registered successfully",
            user: userData,
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.post("/login", async (req, res) => {
    try {
        const { email, phone, password } = req.body;

        const user = await User.findOne({
            where: email ? { email } : { phone },
        });

        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        const match = await bcrypt.compare(password, user.password);

        if (!match) {
            return res.status(400).json({ message: "Wrong password" });
        }

        const token = jwt.sign(
            { id: user.id },
            process.env.JWT_SECRET
        );

        const userData = user.toJSON();
        delete userData.password;

        res.json({
            message: "Login successful",
            token,
            user: userData,
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Auth Middleware
const auth = (req, res, next) => {
    try {
        const token = req.header("Authorization")?.replace("Bearer ", "");

        if (!token) {
            return res.status(401).json({
                message: "No token, authorization denied",
            });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;

        next();
    } catch (err) {
        res.status(401).json({ message: "Token is not valid" });
    }
};

// Get current user profile
router.get("/me", auth, async (req, res) => {
    try {
        const user = await User.findByPk(req.user.id, {
            attributes: { exclude: ["password"] },
        });

        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        res.json(user);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Update user profile
router.put("/profile", auth, async (req, res) => {
    try {
        const { name, email, phone, city, country, profilePicture } = req.body;

        const user = await User.findByPk(req.user.id);

        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        if (email && email !== user.email) {
            const emailExists = await User.findOne({
                where: {
                    email,
                    id: { [Op.ne]: user.id },
                },
            });

            if (emailExists) {
                return res.status(400).json({ message: "Email is already in use" });
            }
        }

        if (phone && phone !== user.phone) {
            const phoneExists = await User.findOne({
                where: {
                    phone,
                    id: { [Op.ne]: user.id },
                },
            });

            if (phoneExists) {
                return res.status(400).json({
                    message: "Phone number is already in use",
                });
            }
        }

        await user.update({
            name: name || user.name,
            email: email || user.email,
            phone: phone || user.phone,
            city: city || user.city,
            country: country || user.country,
            profilePicture: profilePicture || user.profilePicture,
        });

        const updatedUser = await User.findByPk(req.user.id, {
            attributes: { exclude: ["password"] },
        });

        res.json({
            message: "Profile updated successfully",
            user: updatedUser,
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;