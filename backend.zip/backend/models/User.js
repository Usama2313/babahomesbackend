// models/User.js
const { DataTypes } = require("sequelize");
const sequelize = require("../config/database"); // adjust path if needed

const User = sequelize.define(
    "User",
    {
        name: {
            type: DataTypes.STRING,
        },

        email: {
            type: DataTypes.STRING,
            unique: true,
            allowNull: false,
            validate: {
                isEmail: true,
            },
        },

        phone: {
            type: DataTypes.STRING,
            unique: true,
            allowNull: true, // behaves like sparse in MongoDB
        },

        password: {
            type: DataTypes.STRING,
            allowNull: false,
        },

        profilePicture: {
            type: DataTypes.STRING,
        },

        city: {
            type: DataTypes.STRING,
        },

        country: {
            type: DataTypes.STRING,
        },
    },
    {
        tableName: "users",
        timestamps: true, // adds createdAt & updatedAt
    }
);

module.exports = User;