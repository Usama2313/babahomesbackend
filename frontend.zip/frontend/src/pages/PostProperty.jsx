import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import toast from "react-hot-toast";
import {
  X, Users, BriefcaseBusiness, Phone, ShieldCheck, Star, Share2,
  ArrowLeft, ArrowRight, Map, Search, MapPin, Building2,
  LayoutDashboard, Image as ImageIcon, Calendar, Wifi,
  Droplets, Zap, CloudRain, Car, Home, User, CheckCircle
} from "lucide-react";
import API from "../api";
import { countryCityMap } from "../utils/constants";

const PostProperty = () => {
  const navigate = useNavigate();
  const [isStarted, setIsStarted] = useState(false);
  const [step, setStep] = useState(1);
  const [showValidation, setShowValidation] = useState(false);
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    country: "",
    city: "",
    propertyType: "Residential",
    adType: "Rent",
    apartmentType: "",
    bhkType: "",
    floorNo: "",
    totalFloors: "",
    propertyAge: "",
    facing: "",
    builtUpArea: "",
    locality: "",
    landmark: "",
    rentAmount: "",
    rentType: "Monthly Rent",
    securityDeposit: "",
    availableFrom: "",
    bathrooms: "0",
    balconies: "0",
    waterSupply: "",
    petAllowed: "No",
    gym: "No",
    nonVeg: "No",
    gatedSecurity: "No",
    showProperty: "",
    propertyCondition: "",
    amenities: [],
    gallery: [],
    schedule: {
      availableDays: [],
      timeSlot: ""
    }
  });

  const steps = [
    { id: 1, label: "Property Details", icon: Home },
    { id: 2, label: "Locality Details", icon: MapPin },
    { id: 3, label: "Rental Details", icon: Building2 },
    { id: 4, label: "Amenities", icon: LayoutDashboard },
    { id: 5, label: "Gallery", icon: ImageIcon },
    { id: 6, label: "Schedule", icon: Calendar }
  ];

  const handleStart = () => {
    if (!form.city) {
      toast.error("Please select a city to start.");
      return;
    }
    setIsStarted(true);
  };

  const handleNext = () => {
    // Step 1 Validation
    if (step === 1) {
      if (!form.builtUpArea || !form.apartmentType) {
        toast.error("Please fill all required property details.");
        return;
      }
      if (parseInt(form.builtUpArea) < 200) {
        setShowValidation(true);
        return;
      }
    }

    // Step 2 Validation
    if (step === 2) {
      if (!form.country || !form.city || !form.locality) {
        toast.error("Please provide country, city and locality details.");
        return;
      }
    }

    // Step 3 Validation
    if (step === 3) {
      if (!form.rentAmount || !form.securityDeposit) {
        toast.error("Please enter rent and security deposit amounts.");
        return;
      }
    }

    // Step 4 Validation
    if (step === 4) {
      if (!form.bathrooms || !form.showProperty) {
        toast.error("Please fill bathroom count and 'Who will show property'.");
        return;
      }
    }

    if (step < 6) setStep(step + 1);
    else submitProperty();
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const submitProperty = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("babaToken");

      // Convert gallery files to base64
      const galleryBase64 = await Promise.all(
        form.gallery.map(file => new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.readAsDataURL(file);
          reader.onload = () => resolve(reader.result);
          reader.onerror = error => reject(error);
        }))
      );

      const payload = { ...form, gallery: galleryBase64 };

      await API.post("/properties", payload, {
        headers: { Authorization: `Bearer ${token}` }
      });
      toast.success("Property posted successfully!");
      navigate("/");
    } catch (err) {
      toast.error("Error posting property. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const progress = Math.round(((step - 1) / 5) * 100);

  if (!isStarted) {
    return (
      <div className="postIntroPage">
        <div className="postIntroContent">
          <div className="introLeft">
            <h2>Why Post through us?</h2>
            <div className="featureList">
              <div className="featureItem">
                <div className="featureIcon"><X size={20} /></div>
                <div>
                  <h4>Zero Brokerage</h4>
                  <p>100% Free property posting</p>
                </div>
              </div>
              <div className="featureItem">
                <div className="featureIcon"><Users size={20} /></div>
                <div>
                  <h4>Faster Tenants</h4>
                  <p>Connect with genuine seekers</p>
                </div>
              </div>
              <div className="featureItem">
                <div className="featureIcon"><BriefcaseBusiness size={20} /></div>
                <div>
                  <h4>10 lac tenants/buyers connections</h4>
                  <p>Wide reach across GCC & South Asia</p>
                </div>
              </div>
            </div>

            <div className="trustBox">
              <h4>30 Lac+ Home Owners Trust Us</h4>
              <p>"After posting my property ads on Baba Homs, they provided me with an easy way to rent out my apartment... I found the right people."</p>
              <span className="trustee">- Anil | Mumbai</span>
            </div>
          </div>

          <div className="introRight">
            <div className="startForm">
              <div className="citySelectRow">
                <select value={form.country} onChange={e => setForm({ ...form, country: e.target.value, city: "" })}>
                  <option value="">Select Country</option>
                  {Object.keys(countryCityMap).map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
                <select value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} disabled={!form.country}>
                  <option value="">Select City</option>
                  {(countryCityMap[form.country] || []).map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div className="typeSection">
                <p>Property type</p>
                <div className="typeTabs">
                  {["Residential", "Commercial", "Land/Plot"].map(t => (
                    <button
                      key={t}
                      className={form.propertyType === t ? "active" : ""}
                      onClick={() => setForm({ ...form, propertyType: t })}
                    >
                      {t} {t === "Land/Plot" && <span className="newBadge">New</span>}
                    </button>
                  ))}
                </div>
              </div>

              <div className="adTypeSection">
                <p>Select Property Ad Type</p>
                <div className="adTypes">
                  {["Rent", "Resale", "PG/Hostel", "Flatmates"].map(a => (
                    <button
                      key={a}
                      className={form.adType === a ? "active" : ""}
                      onClick={() => setForm({ ...form, adType: a })}
                    >
                      {a}
                    </button>
                  ))}
                </div>
              </div>

              <button
                className="startPostingBtn"
                onClick={handleStart}
                disabled={!form.city || !form.country}
              >
                Start Posting Your Ad For FREE
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="postPropertyLayout">
      <div className="postPropertyHeader">
        <div className="headerLeft">
          <Link to="/" className="logo">
            <span className="box"></span>
            <div>
              <h1>Baba Homs</h1>
              <span>Post Your Property</span>
            </div>
          </Link>
        </div>
        <div className="headerRight">
          <button className="previewBtn">Preview</button>
          <button className="closeBtn" onClick={() => navigate("/")}><X size={20} /></button>
        </div>
      </div>

      <div className="progressBarContainer">
        <div className="progressInfo">
          <span>{progress}% Done</span>
          <div className="mainProgressBar">
            <div className="progressFill" style={{ width: `${progress}%` }}></div>
          </div>
        </div>
      </div>

      <div className="postPropertyBody">
        <aside className="postPropertyLeft">
          {steps.map((s) => (
            <div
              key={s.id}
              className={`sidebarItem ${step === s.id ? "active" : ""} ${step > s.id ? "completed" : ""}`}
              onClick={() => step > s.id && setStep(s.id)}
            >
              <s.icon size={18} />
              <span>{s.label}</span>
              {step > s.id && <CheckCircle size={16} className="checkIcon" />}
            </div>
          ))}
        </aside>

        <main className="postPropertyMain">
          <div className="postPropertyContent">
            {step === 1 && (
              <div className="stepForm">
                <h2>Property Details</h2>
                <div className="formGrid">
                  <div className="formGroup">
                    <label>Apartment Type*</label>
                    <select value={form.apartmentType} onChange={e => setForm({ ...form, apartmentType: e.target.value })}>
                      <option value="">Select</option>
                      <option>Apartment</option>
                      <option>Independent House</option>
                      <option>Villa</option>
                    </select>
                  </div>
                  <div className="formGroup">
                    <label>BHK Type*</label>
                    <select value={form.bhkType} onChange={e => setForm({ ...form, bhkType: e.target.value })}>
                      <option value="">Select</option>
                      <option>1 BHK</option>
                      <option>2 BHK</option>
                      <option>3 BHK</option>
                      <option>4 BHK</option>
                      <option>4+ BHK</option>
                    </select>
                  </div>
                  <div className="formGroup">
                    <label>Floor No</label>
                    <input type="number" value={form.floorNo} onChange={e => setForm({ ...form, floorNo: e.target.value })} />
                  </div>
                  <div className="formGroup">
                    <label>Total Floors</label>
                    <input type="number" value={form.totalFloors} onChange={e => setForm({ ...form, totalFloors: e.target.value })} />
                  </div>
                  <div className="formGroup">
                    <label>Property Age</label>
                    <select value={form.propertyAge} onChange={e => setForm({ ...form, propertyAge: e.target.value })}>
                      <option>New</option>
                      <option>1-3 Years</option>
                      <option>3-5 Years</option>
                      <option>5-10 Years</option>
                      <option>10+ Years</option>
                    </select>
                  </div>
                  <div className="formGroup">
                    <label>Facing</label>
                    <select value={form.facing} onChange={e => setForm({ ...form, facing: e.target.value })}>
                      <option>North</option>
                      <option>South</option>
                      <option>East</option>
                      <option>West</option>
                    </select>
                  </div>
                  <div className="formGroup">
                    <label>Built Up Area*</label>
                    <div className="inputWithUnit">
                      <input
                        type="number"
                        value={form.builtUpArea}
                        onChange={e => setForm({ ...form, builtUpArea: e.target.value })}
                        placeholder="Area"
                      />
                      <span>Sq.ft</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="stepForm">
                <h2>Locality Details</h2>
                <div className="formGrid">
                  <div className="formGroup">
                    <label>Country*</label>
                    <select value={form.country} onChange={e => setForm({ ...form, country: e.target.value, city: "" })}>
                      <option value="">Select Country</option>
                      {Object.keys(countryCityMap).map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                  <div className="formGroup">
                    <label>City*</label>
                    <select value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} disabled={!form.country}>
                      <option value="">Select City</option>
                      {(countryCityMap[form.country] || []).map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                  <div className="formGroup">
                    <label>Locality*</label>
                    <input
                      placeholder="Enter locality"
                      value={form.locality}
                      onChange={e => setForm({ ...form, locality: e.target.value })}
                    />
                  </div>
                  <div className="formGroup fullWidth">
                    <label>Landmark / Street*</label>
                    <input
                      placeholder="Enter landmark"
                      value={form.landmark}
                      onChange={e => setForm({ ...form, landmark: e.target.value })}
                    />
                  </div>
                </div>

                <div className="mapContainer">
                  <div className="mapLabel"><MapPin size={16} /> Mark Locality on Map</div>
                  <p className="mapSub">Set property location by using search box and move the map</p>
                  <div className="mapSearchBox">
                    <Search size={18} color="#999" />
                    <input type="text" placeholder="Search your society or nearest landmark" />
                  </div>
                  <div className="mapWrapper">
                    <div className="mapPlaceholderCustom">
                      <div className="mapSearchOverlay">
                        <Search size={18} color="#999" />
                        <span>{form.locality || form.city || "Search Locality"}</span>
                      </div>
                      <div className="mapMarker">
                        <MapPin size={40} color="#f44336" fill="#f4433633" />
                        <div className="markerPulse"></div>
                      </div>
                      <div className="mapControls">
                        <button>+</button>
                        <button>-</button>
                      </div>
                      <p className="mapHint">Interactive Map View Placeholder (API Key Required for Live Map)</p>
                    </div>
                    <div className="mapOverlay">
                      <MapPin size={32} color="#f44336" />
                      <p>Click to adjust location</p>
                    </div>
                  </div>
                </div>

                <div className="extraLocalityFields">
                  <div className="toggleGroup horizontal">
                    <label>Do you have more similar units/properties available?</label>
                    <div className="btnGroup small">
                      <button className={form.similarUnits === "No" ? "active" : ""} onClick={() => setForm({ ...form, similarUnits: "No" })}>No</button>
                      <button className={form.similarUnits === "Yes" ? "active" : ""} onClick={() => setForm({ ...form, similarUnits: "Yes" })}>Yes</button>
                    </div>
                  </div>

                  <div className="formGroup fullWidth directionTip">
                    <label>Add Directions Tip for your tenants <span className="newBadge">NEW</span></label>
                    <div className="tipInfo">
                      <MapPin size={16} />
                      <p>Don't want calls asking location? Add directions to reach using landmarks</p>
                    </div>
                    <textarea
                      placeholder="Eg. Take the road opposite to Amrita College, take right after 300m..."
                      value={form.directionTip}
                      onChange={e => setForm({ ...form, directionTip: e.target.value })}
                    />
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="stepForm">
                <h2>Provide rental details about your property</h2>
                <div className="formGrid">
                  <div className="formGroup fullWidth">
                    <label>Property available for</label>
                    <div className="radioGroup">
                      <label><input type="radio" name="availableFor" checked={form.availableFor === 'Rent'} onChange={() => setForm({ ...form, availableFor: 'Rent' })} /> Only rent</label>
                      <label><input type="radio" name="availableFor" checked={form.availableFor === 'Lease'} onChange={() => setForm({ ...form, availableFor: 'Lease' })} /> Only lease</label>
                    </div>
                  </div>

                  <div className="formGroup">
                    <label>Expected Rent*</label>
                    <div className="inputWithUnit">
                      <span>₹</span>
                      <input type="number" placeholder="Enter Amount" value={form.rentAmount} onChange={e => setForm({ ...form, rentAmount: e.target.value })} />
                      <span>/ Month</span>
                    </div>
                    <div className="amountInWords">₹ {form.rentAmount ? (form.rentAmount / 1000).toFixed(2) + ' k' : '0.00 k'}</div>
                  </div>

                  <div className="formGroup">
                    <label>Expected Deposit*</label>
                    <div className="inputWithUnit">
                      <span>₹</span>
                      <input type="number" placeholder="Enter Amount" value={form.securityDeposit} onChange={e => setForm({ ...form, securityDeposit: e.target.value })} />
                    </div>
                    <div className="amountInWords">₹ {form.securityDeposit ? (form.securityDeposit / 1000).toFixed(2) + ' k' : '0.00 k'}</div>
                  </div>

                  <div className="formGroup fullWidth">
                    <label className="checkboxLabel">
                      <input type="checkbox" checked={form.rentNegotiable} onChange={e => setForm({ ...form, rentNegotiable: e.target.checked })} />
                      Rent Negotiable
                    </label>
                  </div>

                  <div className="formGroup">
                    <label>Monthly Maintenance</label>
                    <select value={form.maintenanceType} onChange={e => setForm({ ...form, maintenanceType: e.target.value })}>
                      <option>Maintenance Extra</option>
                      <option>Maintenance Included</option>
                    </select>
                  </div>

                  <div className="formGroup">
                    <label>Maintenance Amount*</label>
                    <div className="inputWithUnit">
                      <span>₹</span>
                      <input type="number" placeholder="Amount" value={form.maintenanceAmount} onChange={e => setForm({ ...form, maintenanceAmount: e.target.value })} />
                      <span>/ Month</span>
                    </div>
                  </div>

                  <div className="formGroup">
                    <label>Available From*</label>
                    <input type="date" value={form.availableFrom} onChange={e => setForm({ ...form, availableFrom: e.target.value })} />
                  </div>

                  <div className="formGroup fullWidth">
                    <label>Preferred Tenants*</label>
                    <div className="checkboxGroup">
                      {['Anyone', 'Family', 'Bachelor Female', 'Bachelor Male', 'Company'].map(t => (
                        <label key={t}>
                          <input
                            type="checkbox"
                            checked={form.preferredTenants?.includes(t)}
                            onChange={e => {
                              const tenants = form.preferredTenants || [];
                              if (e.target.checked) setForm({ ...form, preferredTenants: [...tenants, t] });
                              else setForm({ ...form, preferredTenants: tenants.filter(item => item !== t) });
                            }}
                          /> {t}
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="formGroup">
                    <label>Furnishing*</label>
                    <select value={form.furnishing} onChange={e => setForm({ ...form, furnishing: e.target.value })}>
                      <option>Fully furnished</option>
                      <option>Semi furnished</option>
                      <option>Unfurnished</option>
                    </select>
                  </div>

                  <div className="formGroup">
                    <label>Parking*</label>
                    <select value={form.parking} onChange={e => setForm({ ...form, parking: e.target.value })}>
                      <option>Car</option>
                      <option>Bike</option>
                      <option>Both</option>
                      <option>None</option>
                    </select>
                  </div>

                  <div className="formGroup fullWidth">
                    <label>Description</label>
                    <textarea
                      placeholder="Write a few lines about your property..."
                      value={form.description}
                      onChange={e => setForm({ ...form, description: e.target.value })}
                      rows={4}
                    />
                  </div>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="stepForm amenitiesStep">
                <h2 className="stepTitle">Provide additional details about your property to get maximum visibility</h2>

                <div className="formGrid threeCol">
                  <div className="formGroup">
                    <label>Bathroom(s)*</label>
                    <div className="stepper">
                      <button onClick={() => setForm({ ...form, bathrooms: Math.max(0, parseInt(form.bathrooms || 0) - 1).toString() })}>-</button>
                      <span>{form.bathrooms || 0}</span>
                      <button onClick={() => setForm({ ...form, bathrooms: (parseInt(form.bathrooms || 0) + 1).toString() })}>+</button>
                    </div>
                  </div>
                  <div className="formGroup">
                    <label>Balcony</label>
                    <div className="stepper">
                      <button onClick={() => setForm({ ...form, balconies: Math.max(0, parseInt(form.balconies || 0) - 1).toString() })}>-</button>
                      <span>{form.balconies || 0}</span>
                      <button onClick={() => setForm({ ...form, balconies: (parseInt(form.balconies || 0) + 1).toString() })}>+</button>
                    </div>
                  </div>
                  <div className="formGroup">
                    <label>Water Supply</label>
                    <select value={form.waterSupply} onChange={e => setForm({ ...form, waterSupply: e.target.value })}>
                      <option value="">Select</option>
                      <option>Corporation</option>
                      <option>Borewell</option>
                      <option>Both</option>
                    </select>
                  </div>
                </div>

                <div className="binaryTogglesGrid">
                  {[
                    { label: "Pet Allowed*", key: "petAllowed", icon: <Users size={16} /> },
                    { label: "Gym*", key: "gym", icon: <BriefcaseBusiness size={16} /> },
                    { label: "Non-Veg Allowed*", key: "nonVeg", icon: <LayoutDashboard size={16} /> },
                    { label: "Gated Security*", key: "gatedSecurity", icon: <ShieldCheck size={16} /> }
                  ].map(item => (
                    <div key={item.key} className="toggleGroup">
                      <div className="toggleLabel">
                        {item.icon}
                        <label>{item.label}</label>
                      </div>
                      <div className="btnGroup">
                        <button className={form[item.key] === "No" ? "active" : ""} onClick={() => setForm({ ...form, [item.key]: "No" })}>No</button>
                        <button className={form[item.key] === "Yes" ? "active" : ""} onClick={() => setForm({ ...form, [item.key]: "Yes" })}>Yes</button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="formGrid twoCol">
                  <div className="formGroup">
                    <label>Who will show the property?*</label>
                    <select value={form.showProperty} onChange={e => setForm({ ...form, showProperty: e.target.value })}>
                      <option value="">Select</option>
                      <option>Self</option>
                      <option>Agent</option>
                      <option>Caretaker</option>
                    </select>
                  </div>
                  <div className="formGroup">
                    <label>Current Property Condition?</label>
                    <select value={form.propertyCondition} onChange={e => setForm({ ...form, propertyCondition: e.target.value })}>
                      <option value="">Select</option>
                      <option>New</option>
                      <option>Resale</option>
                      <option>Under Construction</option>
                    </select>
                  </div>
                </div>

                <div className="amenitiesSection">
                  <h3 className="sectionLabel">Select the available amenities</h3>
                  <div className="amenitiesCheckboxGrid">
                    {[
                      { name: "Lift", icon: <Building2 size={16} /> },
                      { name: "Internet Services", icon: <Wifi size={16} /> },
                      { name: "Air Conditioner", icon: <Home size={16} /> },
                      { name: "Club House", icon: <Users size={16} /> },
                      { name: "Intercom", icon: <Phone size={16} /> },
                      { name: "Swimming Pool", icon: <Droplets size={16} /> },
                      { name: "Children Play Area", icon: <Users size={16} /> },
                      { name: "Fire Safety", icon: <ShieldCheck size={16} /> },
                      { name: "Servant Room", icon: <User size={16} /> },
                      { name: "Shopping Center", icon: <Building2 size={16} /> },
                      { name: "Gas Pipeline", icon: <Zap size={16} /> },
                      { name: "Park", icon: <Map size={16} /> },
                      { name: "Rain Water Harvesting", icon: <CloudRain size={16} /> },
                      { name: "Sewage Treatment Plant", icon: <Droplets size={16} /> },
                      { name: "House Keeping", icon: <User size={16} /> },
                      { name: "Power Backup", icon: <Zap size={16} /> },
                      { name: "Visitor Parking", icon: <Car size={16} /> }
                    ].map(amenity => (
                      <label key={amenity.name} className="amenityCheck">
                        <input
                          type="checkbox"
                          checked={form.amenities.includes(amenity.name)}
                          onChange={e => {
                            const newAmenities = e.target.checked
                              ? [...form.amenities, amenity.name]
                              : form.amenities.filter(a => a !== amenity.name);
                            setForm({ ...form, amenities: newAmenities });
                          }}
                        />
                        <div className="checkContent">
                          {amenity.icon}
                          <span>{amenity.name}</span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {step === 5 && (
              <div className="stepForm galleryStep">
                <div className="galleryHeader">
                  <h2>Upload photos & videos</h2>
                  <button className="phoneUploadBtn"><Phone size={16} /> Upload through phone</button>
                </div>

                <div className="uploadContainer">
                  <div className="uploadBoxMain" onClick={() => document.getElementById('fileInput').click()}>
                    <div className="uploadIconLarge">
                      <ImageIcon size={48} color="#999" />
                    </div>
                    <h3>Add photos to get 5X more responses.</h3>
                    <p>90% tenants contact on properties with photos.</p>
                    <button className="addPhotosBtn">Add Photos</button>
                    <input
                      id="fileInput"
                      type="file"
                      multiple
                      hidden
                      accept="image/*,video/*"
                      onChange={e => {
                        const files = Array.from(e.target.files);
                        setForm({ ...form, gallery: [...form.gallery, ...files] });
                      }}
                    />
                  </div>

                  <div className="uploadDivider">
                    <span>OR</span>
                  </div>

                  <div className="behalfUpload">
                    <p>We can upload photos on your behalf</p>
                  </div>
                </div>

                {form.gallery.length > 0 && (
                  <div className="galleryScrollContainer">
                    <div className="galleryPreviewHorizontal">
                      {form.gallery.map((f, i) => (
                        <div key={i} className="galleryItemCard">
                          <div className="filePreview">
                            {f.type.startsWith('video/')
                              ? <video src={URL.createObjectURL(f)} className="thumbVideo" />
                              : <img src={URL.createObjectURL(f)} alt={f.name} className="thumbImg" />
                            }
                          </div>
                          <div className="fileInfo">
                            <span className="fileName">{f.name}</span>
                            <span className="fileSize">{(f.size / 1024).toFixed(1)} KB</span>
                          </div>
                          <button className="removeFile" onClick={() => setForm({ ...form, gallery: form.gallery.filter((_, idx) => idx !== i) })}>&times;</button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {step === 6 && (
              <div className="stepForm">
                <h2>Select Schedule</h2>
                <div className="formGrid">
                  <div className="formGroup fullWidth">
                    <label>Availability Days*</label>
                    <div className="checkboxGroup">
                      {['All days', 'Weekdays', 'Weekends'].map(d => (
                        <label key={d}>
                          <input type="checkbox" checked={form.schedule.availableDays.includes(d)} onChange={e => {
                            const days = form.schedule.availableDays;
                            if (e.target.checked) setForm({ ...form, schedule: { ...form.schedule, availableDays: [...days, d] } });
                            else setForm({ ...form, schedule: { ...form.schedule, availableDays: days.filter(i => i !== d) } });
                          }} /> {d}
                        </label>
                      ))}
                    </div>
                  </div>
                  <div className="formGroup fullWidth">
                    <label>Time Slot*</label>
                    <div className="radioGroup">
                      {['Morning', 'Afternoon', 'Evening', 'Night'].map(t => (
                        <label key={t}>
                          <input type="radio" name="timeSlot" checked={form.schedule.timeSlot === t} onChange={() => setForm({ ...form, schedule: { ...form.schedule, timeSlot: t } })} /> {t}
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="helpBanner">
              <div className="helpIcon"><Phone size={18} /></div>
              <p>Don't want to fill all the details? Let us help you!</p>
              <button className="helpBtn">I'm interested</button>
            </div>
          </div>
        </main>

        <aside className="postPropertyRight">
          <div className="promoCard">
            <h3>Get Tenants Faster</h3>
            <p>Subscribe to our owner plans and find Tenants quickly and with ease</p>
            <ul className="promoList">
              <li><ShieldCheck size={16} /> Privacy</li>
              <li><Star size={16} /> Promoted Listing</li>
              <li><Share2 size={16} /> Social Marketing</li>
              <li><Users size={16} /> Price Consultation</li>
            </ul>
          </div>
        </aside>
      </div>

      <div className="postPropertyFooter">
        {step > 1 && <button className="backBtn" onClick={handleBack} disabled={loading}><ArrowLeft size={18} /> Back</button>}
        <button className="continueBtn" onClick={handleNext} disabled={loading}>
          {loading ? "Posting..." : (step === 6 ? "Finish" : "Save & Continue")}
          {!loading && step < 6 && <ArrowRight size={18} />}
        </button>
      </div>

      <AnimatePresence>
        {showValidation && (
          <motion.div
            className="modalOverlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="validationModal"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
            >
              <div className="modalIcon">
                <div className="warningCircle">
                  <Home size={40} color="#ff9800" />
                  <div className="percentIcon">%</div>
                </div>
              </div>
              <p className="modalText">
                <strong>{form.builtUpArea} Sq.ft</strong> is too small for a <strong>{form.bhkType}</strong>, Do You want to recheck this data?
              </p>
              <div className="modalActions">
                <button className="changeBtn" onClick={() => setShowValidation(false)}>I want to change it</button>
                <button className="correctBtn" onClick={() => { setShowValidation(false); setStep(step + 1); }}>The data is correct</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default PostProperty;
