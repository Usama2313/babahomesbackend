import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import API from "../api";
import { fallbackProperties } from "../utils/constants";

const PropertyDetails = () => {
  const { id } = useParams();
  const [property, setProperty] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await API.get(`/properties/${id}`);
        setProperty(res.data);
      } catch {
        setProperty(fallbackProperties.find((p) => p._id === id));
      }
    };

    load();
  }, [id]);

  if (!property) return <div className="pageMessage">Property not found.</div>;

  return (
    <section className="detailsPage">
      <div className="mainImage">
        <img src={property.gallery?.[0] || property.image} alt={property.title} />
      </div>

      <div className="detailsBox">
        <h1>{property.title}</h1>
        <p>{property.address}</p>
        <h2>{property.currency} {Number(property.price || property.rentAmount).toLocaleString()}</h2>

        {property.gallery?.length > 0 && (
          <div className="gallerySection">
            <h3>Property Gallery</h3>
            <div className="horizontalGallery">
              {property.gallery.map((item, idx) => (
                <div key={idx} className="galleryThumb">
                  {item.startsWith('data:video') ? (
                    <video src={item} controls />
                  ) : (
                    <img src={item} alt={`Gallery ${idx}`} />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="detailsGrid">
          <span>City: {property.city}</span>
          <span>Type: {property.apartmentType || property.type}</span>
          <span>BHK: {property.bhkType}</span>
          <span>Area: {property.builtUpArea || property.area} Sq.ft</span>
          <span>Facing: {property.facing}</span>
          <span>Status: {property.availableFrom ? `Available from ${property.availableFrom}` : 'Contact for status'}</span>
        </div>

        <Link to="/" className="backBtn">Back to Home</Link>
      </div>
    </section>
  );
};

export default PropertyDetails;
