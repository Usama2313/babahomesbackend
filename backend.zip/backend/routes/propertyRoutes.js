// routes/propertyRoutes.js
const express = require("express");
const jwt = require("jsonwebtoken");
const { Op } = require("sequelize");
const Property = require("../models/Property");

const router = express.Router();

// Auth Middleware
const auth = (req, res, next) => {
    try {
        const token = req.header("Authorization")?.replace("Bearer ", "");

        if (!token) {
            return res.status(401).json({ message: "No token, authorization denied" });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        res.status(401).json({ message: "Token is not valid" });
    }
};

// GET all properties with filters, search, pagination
router.get("/", async (req, res) => {
    try {
        const {
            country,
            city,
            type,
            category,
            search,
            owner,
            page = 1,
            limit = 20,
        } = req.query;

        const where = {};

        if (country) where.country = country;
        if (city) where.city = city;
        if (type) where.type = type;
        if (category) where.category = category;
        if (owner) where.owner = owner;

        if (search) {
            where[Op.or] = [
                { title: { [Op.like]: `%${search}%` } },
                { city: { [Op.like]: `%${search}%` } },
                { country: { [Op.like]: `%${search}%` } },
                { address: { [Op.like]: `%${search}%` } },
            ];
        }

        const pageNumber = parseInt(page, 10);
        const limitNumber = parseInt(limit, 10);
        const offset = (pageNumber - 1) * limitNumber;

        const totalProperties = await Property.count({ where });

        const properties = await Property.findAll({
            where,
            order: [["createdAt", "DESC"]],
            offset,
            limit: limitNumber,
        });

        res.json({
            data: properties,
            currentPage: pageNumber,
            totalPages: Math.ceil(totalProperties / limitNumber),
            totalProperties,
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// GET single property by id
router.get("/:id", async (req, res) => {
    try {
        const property = await Property.findByPk(req.params.id);

        if (!property) {
            return res.status(404).json({ message: "Property not found" });
        }

        res.json(property);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// CREATE property
router.post("/", auth, async (req, res) => {
    try {
        const property = await Property.create({
            ...req.body,
            owner: req.user.id,
        });

        res.status(201).json(property);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// UPDATE property
router.put("/:id", auth, async (req, res) => {
    try {
        const property = await Property.findOne({
            where: {
                id: req.params.id,
                owner: req.user.id,
            },
        });

        if (!property) {
            return res.status(404).json({
                message: "Property not found or unauthorized",
            });
        }

        await property.update(req.body);

        res.json(property);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// DELETE property
router.delete("/:id", auth, async (req, res) => {
    try {
        const property = await Property.findOne({
            where: {
                id: req.params.id,
                owner: req.user.id,
            },
        });

        if (!property) {
            return res.status(404).json({
                message: "Property not found or unauthorized",
            });
        }

        await property.destroy();

        res.json({ message: "Property deleted" });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;