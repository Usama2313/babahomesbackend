import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import toast from "react-hot-toast";
import API from "../api";

const AuthPage = ({ type }) => {
  const navigate = useNavigate();
  const isSignup = type === "signup";

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });

  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const submitAuth = async (e) => {
    e.preventDefault();
    setMessage("");

    if (isSignup && form.password !== form.confirmPassword) {
      toast.error("Passwords do not match.");
      setMessage("Passwords do not match.");
      return;
    }

    try {
      setLoading(true);

      const url = isSignup ? "/auth/register" : "/auth/login";

      const payload = isSignup
        ? { name: form.name, email: form.email, phone: form.phone, password: form.password }
        : { email: form.email, phone: form.phone, password: form.password };

      const res = await API.post(url, payload);

      if (isSignup) {
        toast.success("Account created successfully. Please login.");
        setMessage("Account created successfully. Please login.");
        setTimeout(() => navigate("/login"), 900);
      } else {
        localStorage.setItem("babaToken", res.data.token);
        localStorage.setItem("babaUser", JSON.stringify(res.data.user));
        toast.success(`Welcome back, ${res.data.user.name}!`);
        navigate("/post-property");
      }
    } catch (error) {
      setMessage(error.response?.data?.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="loginPage">
      <motion.form
        className="loginCard"
        onSubmit={submitAuth}
        initial={{ opacity: 0, scale: 0.92, y: 25 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
      >
        <h1>{isSignup ? "Create Baba Homs Account" : "Login"}</h1>

        {isSignup && (
          <input
            placeholder="Full Name"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            required
          />
        )}

        <input
          placeholder="Email Address"
          type="email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          required={!form.phone}
        />

        <div className="phoneInput">
          <input
            placeholder="Phone Number"
            type="tel"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            required={!form.email}
          />
        </div>

        <input
          placeholder="Password"
          type="password"
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          required
        />

        {isSignup && (
          <input
            placeholder="Confirm Password"
            type="password"
            value={form.confirmPassword}
            onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })}
            required
          />
        )}

        <button type="submit" disabled={loading}>
          {loading ? "Processing..." : isSignup ? "Sign Up" : "Login"}
        </button>

        {message && <p className="message">{message}</p>}

        <p className="switch">
          {isSignup ? "Already have an account?" : "Don't have an account?"}{" "}
          <span onClick={() => navigate(isSignup ? "/login" : "/signup")}>
            {isSignup ? "Login here" : "Create one"}
          </span>
        </p>
      </motion.form>
    </section>
  );
};

export default AuthPage;
