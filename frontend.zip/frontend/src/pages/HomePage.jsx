import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Home, Building2, BriefcaseBusiness, Users,
  Search, MapPin, Mic
} from "lucide-react";
import toast from "react-hot-toast";
import API from "../api";
import { countryCityMap, fallbackProperties } from "../utils/constants";

const HomePage = () => {
  const navigate = useNavigate();

  const [selectedCountry, setSelectedCountry] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState("Buy");
  const [propertyType, setPropertyType] = useState("");
  const [properties, setProperties] = useState(fallbackProperties);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const token = localStorage.getItem("babaToken");
  const countries = Object.keys(countryCityMap);
  const cities = selectedCountry ? countryCityMap[selectedCountry] : [];

  const fetchProperties = async (pageNum = 1) => {
    try {
      if (pageNum === 1) setLoading(true);

      // Build query string
      let query = `/properties?page=${pageNum}&limit=20`;
      if (selectedCountry) query += `&country=${selectedCountry}`;
      if (selectedCity) query += `&city=${selectedCity}`;
      if (propertyType) query += `&type=${propertyType}`;

      const res = await API.get(query);

      const incomingProps = res.data.data || res.data;
      const parsedTotal = res.data.totalPages || 1;

      if (incomingProps && incomingProps.length > 0) {
        if (pageNum === 1) {
          // If very few properties, pad with fallbacks
          if (incomingProps.length < 3) {
            const needed = 3 - incomingProps.length;
            setProperties([...incomingProps, ...fallbackProperties.slice(0, needed)]);
          } else {
            setProperties(incomingProps);
          }
        } else {
          setProperties(prev => [...prev, ...incomingProps]);
        }
        setTotalPages(parsedTotal);
      } else if (pageNum === 1) {
        setProperties(fallbackProperties);
      }
    } catch (err) {
      console.error("API Error:", err);
      if (pageNum === 1) setProperties(fallbackProperties);
      toast.error("Failed to connect to database. Showing offline properties.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setPage(1);
    fetchProperties(1);
  }, [selectedCountry, selectedCity, activeTab, propertyType]);

  const detectLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          toast.success("Location detected! Finding properties near you...");
        },
        () => toast.error("Location access denied. Please enable it in your browser.")
      );
    }
  };

  const voiceSearch = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      toast.error("Voice search is not supported in this browser.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.start();

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setSearch(transcript);
      toast.success(`Searching for: ${transcript}`);
    };
  };

  const filteredProperties = properties.filter((p) => {
    const countryMatch = selectedCountry ? p.country === selectedCountry : true;
    const cityMatch = selectedCity ? p.city === selectedCity : true;
    const typeMatch = propertyType ? p.type === propertyType : true;
    const searchMatch = search
      ? `${p.title || ""} ${p.city || ""} ${p.country || ""} ${p.address || ""}`.toLowerCase().includes(search.toLowerCase())
      : true;

    return countryMatch && cityMatch && typeMatch && searchMatch;
  });

  const displayProperties = token ? filteredProperties : filteredProperties.slice(0, 3);

  return (
    <>
      <section className="hero">
        <motion.div
          className="heroContent"
          initial={{ opacity: 0, y: 35 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.6 }}
          >
            Find Your Dream Property <br />
            Across GCC & South Asia
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
          >
            Baba Homs helps you buy, rent, and invest in properties across{" "}
            <span>UAE, Saudi Arabia, Bahrain, Qatar, India & Pakistan</span>
          </motion.p>

          <div className="searchPanel">
            <div className="tabs">
              {[
                ["Buy", Home],
                ["Rental", Home],
                ["Projects", Building2],
                ["Commercial", BriefcaseBusiness],
              ].map(([name, Icon], index) => (
                <motion.button
                  key={name}
                  className={activeTab === name ? "active" : ""}
                  onClick={() => setActiveTab(name)}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Icon size={16} /> {name}
                </motion.button>
              ))}
            </div>

            <motion.div
              className="searchBar"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              <select value={selectedCountry} onChange={(e) => { setSelectedCountry(e.target.value); setSelectedCity(""); }}>
                <option value="">Select Country</option>
                {countries.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>

              <select value={selectedCity} onChange={(e) => setSelectedCity(e.target.value)}>
                <option value="">Select City</option>
                {cities.map((city) => (
                  <option key={city} value={city}>{city}</option>
                ))}
              </select>

              <div className="inputBox">
                <Search size={23} color="#777" />
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder='Search by "City, Locality or Project"'
                />
                <button className="iconBtn" onClick={detectLocation}>
                  <MapPin size={21} />
                </button>
                <button className="iconBtn" onClick={voiceSearch}>
                  <Mic size={21} />
                </button>
              </div>

              <motion.button
                className="searchBtn"
                onClick={() => { setPage(1); fetchProperties(1); }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Search
              </motion.button>
            </motion.div>
          </div>

          <motion.div
            className="filters"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <select>
              <option>Budget</option>
              <option>Low Budget</option>
              <option>Medium Budget</option>
              <option>High Budget</option>
            </select>

            <select value={propertyType} onChange={(e) => setPropertyType(e.target.value)}>
              <option value="">Property Type</option>
              <option value="Apartment">Apartment</option>
              <option value="Villa">Villa</option>
              <option value="House">House</option>
            </select>

            <select>
              <option>Possession Status</option>
              <option>Ready to Move</option>
              <option>Under Construction</option>
            </select>
          </motion.div>
        </motion.div>
      </section>

      <section className="propertySection">
        <h2>{selectedCity ? `Properties in ${selectedCity}` : "Baba Homs Featured Properties"}</h2>
        <p>Explore premium properties in top cities across GCC and South Asia.</p>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '40px', gridColumn: '1 / -1' }}>
            <div className="loaderSpinner"></div>
            <p>Loading properties...</p>
          </div>
        ) : (
          <div className="cards">
            {displayProperties.map((property, index) => (
              <motion.div
                className="card"
                key={property._id}
                initial={{ opacity: 0, y: 35 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.12 }}
                viewport={{ once: true }}
              >
                {(() => {
                  const mediaSrc = property.gallery?.[0] || property.image || "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80";
                  if (mediaSrc.startsWith('data:video')) {
                    return <video src={mediaSrc} className="cardMedia" controls={false} autoPlay muted loop />;
                  }
                  return <img src={mediaSrc} alt={property.title} className="cardMedia" />;
                })()}

                <div className="cardBody">
                  <h3>{property.title || `${property.bhkType || ''} ${property.apartmentType || property.type || 'Property'} in ${property.locality || property.city || ''}`}</h3>
                  <p>{property.city}, {property.country}</p>
                  <strong>{property.currency || '₹'} {Number(property.price || property.rentAmount || 0).toLocaleString()}</strong>

                  <button onClick={() => navigate(`/property/${property._id}`)}>
                    View Property
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {page < totalPages && !loading && (
          <div style={{ textAlign: "center", marginTop: "30px" }}>
            <button
              className="continueBtn"
              onClick={() => {
                const nextPage = page + 1;
                setPage(nextPage);
                fetchProperties(nextPage);
              }}
            >
              Load More
            </button>
          </div>
        )}
      </section>
    </>
  );
};

export default HomePage;
