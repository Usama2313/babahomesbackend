import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import {
  Menu, X, Heart, User, ChevronDown, List,
  MessageSquare, Settings, LogOut
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const Navbar = ({ token, user, open, setOpen, activeDropdown, setActiveDropdown }) => {
  const navRef = useRef(null);

  const closeMobile = () => setOpen(false);

  const dropdowns = [
    { title: "Buy", items: ["Residential Apartment", "Independent House", "Villa", "Plot"] },
    { title: "Rent", items: ["Apartment", "House/Villa", "PG/Hostel", "Flatmates"] },
    { title: "Commercial", items: ["Office Space", "Shop/Showroom", "Warehouse", "Industrial"] }
  ];

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (navRef.current && !navRef.current.contains(e.target)) {
        setActiveDropdown(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [setActiveDropdown]);

  return (
    <nav className="navbar" ref={navRef}>
      {/* Logo */}
      <Link to="/" className="navLogo" onClick={closeMobile}>
        <span className="logoBox"></span>
        <div className="logoText">
          <strong>Baba Homs</strong>
          <small>Real Estate Platform</small>
        </div>
      </Link>

      {/* Desktop Links */}
      <div className="navCenter">
        {dropdowns.map(({ title, items }) => (
          <div className="navDropItem" key={title}>
            <button
              className="navDropBtn"
              onClick={() => setActiveDropdown(activeDropdown === title ? null : title)}
            >
              {title} <ChevronDown size={13} />
            </button>

            <AnimatePresence>
              {activeDropdown === title && (
                <motion.div
                  className="navDropMenu"
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.18 }}
                >
                  {items.map((item) => (
                    <Link key={item} to="/" className="navDropMenuItem" onClick={closeMobile}>
                      {item}
                    </Link>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
        <Link to="/" className="navPlainLink" onClick={closeMobile}>Blogs</Link>
      </div>

      {/* Desktop Actions */}
      <div className="navRight">
        <button className="navAdvBtn">Advertise with us</button>
        <Link to="/post-property" className="navSellBtn" onClick={closeMobile}>
          Sell or Rent Property
        </Link>
        <Heart size={20} color="white" style={{ cursor: "pointer" }} />

        {token ? (
          <div className="navUser">
            <button
              className="navUserBtn"
              onClick={(e) => {
                e.stopPropagation();
                setActiveDropdown(activeDropdown === "user" ? null : "user");
              }}
            >
              <div className="navAvatar">
                {user?.profilePicture ? (
                  <img src={user.profilePicture} alt="User" style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} />
                ) : (
                  user?.name ? user.name.charAt(0).toUpperCase() : <User size={18} />
                )}
              </div>
              <span>{user?.name || "Account"}</span>
              <ChevronDown size={13} />
            </button>

            <AnimatePresence>
              {activeDropdown === "user" && (
                <motion.div
                  className="navProfileMenu"
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.18 }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <Link to="/post-property" onClick={() => setActiveDropdown(null)}>
                    <List size={15} /> My Properties
                  </Link>
                  <a href="https://wa.me/919849787154" target="_blank" rel="noopener noreferrer" onClick={() => setActiveDropdown(null)}>
                    <MessageSquare size={15} /> Chat on WhatsApp
                  </a>
                  <Link to="/profile" onClick={() => setActiveDropdown(null)}>
                    <User size={15} /> Profile
                  </Link>
                  <button onClick={() => { localStorage.clear(); window.location.href = "/"; }}>
                    <LogOut size={15} /> Logout
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ) : (
          <div className="navAuthBtns">
            <Link to="/login" className="navLoginBtn" onClick={closeMobile}>Log in</Link>
            <Link to="/signup" className="navSignupBtn" onClick={closeMobile}>Sign up</Link>
          </div>
        )}
      </div>

      {/* Mobile Hamburger */}
      <button className="navHamburger" onClick={() => setOpen(!open)}>
        {open ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {open && (
          <motion.div
            className="navMobileMenu"
            initial={{ opacity: 0, x: "100%" }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: "100%" }}
            transition={{ duration: 0.25 }}
          >
            <div className="mobileMenuInner">
              {dropdowns.map(({ title, items }) => (
                <div key={title} className="mobileDropSection">
                  <button
                    className="mobileDropTitle"
                    onClick={() => setActiveDropdown(activeDropdown === title ? null : title)}
                  >
                    {title} <ChevronDown size={14} />
                  </button>
                  {activeDropdown === title && (
                    <div className="mobileDropItems">
                      {items.map((item) => (
                        <Link key={item} to="/" className="mobileDropItem" onClick={closeMobile}>
                          {item}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              <Link to="/" className="mobileNavLink" onClick={closeMobile}>Blogs</Link>
              <hr className="mobileDivider" />
              <Link to="/post-property" className="mobileSellBtn" onClick={closeMobile}>
                Sell or Rent Property
              </Link>
              {token ? (
                <div className="mobileUserSection">
                  <Link to="/profile" onClick={closeMobile}>My Profile</Link>
                  <Link to="/post-property" onClick={closeMobile}>My Properties</Link>
                  <a href="https://wa.me/929849787154" target="_blank" rel="noopener noreferrer" onClick={closeMobile}>
                    Chat on WhatsApp
                  </a>
                  <button onClick={() => { localStorage.clear(); window.location.href = "/"; }}>
                    Logout
                  </button>
                </div>
              ) : (
                <div className="mobileAuthBtns">
                  <Link to="/login" onClick={closeMobile}>Log in</Link>
                  <Link to="/signup" onClick={closeMobile}>Sign up</Link>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
