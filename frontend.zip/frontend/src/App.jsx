import { Routes, Route, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import { Toaster } from "react-hot-toast";
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";

// Pages
import HomePage from "./pages/HomePage";
import PropertyDetails from "./pages/PropertyDetails";
import AuthPage from "./pages/AuthPage";
import PostProperty from "./pages/PostProperty";

import ProfilePage from "./pages/ProfilePage";

// Styles
import "./App.css";

function App() {
  const [open, setOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("babaToken"));
  const [user, setUser] = useState(JSON.parse(localStorage.getItem("babaUser") || "{}"));
  const location = useLocation();

  // Update token/user state when storage changes (e.g. after login)
  useEffect(() => {
    const handleStorageChange = () => {
      setToken(localStorage.getItem("babaToken"));
      setUser(JSON.parse(localStorage.getItem("babaUser") || "{}"));
    };
    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  // Sync state manually after navigation if needed
  useEffect(() => {
    setToken(localStorage.getItem("babaToken"));
    setUser(JSON.parse(localStorage.getItem("babaUser") || "{}"));
    setOpen(false);
    setActiveDropdown(null);
  }, [location.pathname]);

  // Hide Navbar on PostProperty page to match design
  const showNavbar = location.pathname !== "/post-property" && location.pathname !== "/profile";

  return (
    <>
      <Toaster position="top-right" />
      {showNavbar && (
        <Navbar
          token={token}
          user={user}
          open={open}
          setOpen={setOpen}
          activeDropdown={activeDropdown}
          setActiveDropdown={setActiveDropdown}
        />
      )}

      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/property/:id" element={<PropertyDetails />} />
        <Route path="/login" element={<AuthPage type="login" />} />
        <Route path="/signup" element={<AuthPage type="signup" />} />
        <Route path="/post-property" element={
          <ProtectedRoute>
            <PostProperty />
          </ProtectedRoute>
        } />
        <Route path="/profile" element={
          <ProtectedRoute>
            <ProfilePage />
          </ProtectedRoute>
        } />
      </Routes>
    </>
  );
}

export default App;